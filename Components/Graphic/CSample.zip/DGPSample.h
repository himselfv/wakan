//---------------------------------------------------------------------------
#ifndef DGPSampleH
#define DGPSampleH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include "ClrPanel.hpp"
#include <vcl\ExtCtrls.hpp>
#include "DFCtrls.hpp"
#include "DFClasses.hpp"
#include "ArtLabel.hpp"
#include "ColorBtns.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TColorPanel *ColorPanel1;
	TApples *Apples1;
	TArtLabel *ArtLabel1;
	TBCBitmap *BCBitmap1;
	TArtLabel *ArtLabel2;
	TColor95Button *Color95Button1;
	TColor95Button *Color95Button2;
	TColor95Button *Color95Button3;
	TColorPanel *ColorPanel2;
	TColor95Button *Color95Button6;
	TColor95Button *Color95Button7;
	TColor95Button *Color95Button4;
	TColor95Button *Color95Button5;
	TColor95Button *Color95Button8;
	void __fastcall Color95Button4Click(TObject *Sender);
	void __fastcall Color95Button5Click(TObject *Sender);
	void __fastcall Color95Button6Click(TObject *Sender);
	void __fastcall Color95Button7Click(TObject *Sender);
	void __fastcall Color95Button8Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
