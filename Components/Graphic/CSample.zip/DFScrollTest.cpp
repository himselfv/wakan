/*
	First time Ceeing, anything does not match your eye, just
  leave it, I don't care! 
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "DFScrollTest.h"
//---------------------------------------------------------------------------
#pragma link "DFCtrls"
#pragma link "DFClasses"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DFScroll1Change(TObject *Sender)
{
  char buffer[80];

  sprintf(buffer, "Position is %d", DFScroll1->Position);

	Label1->Caption=buffer;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
	DFScroll4->PageDown();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DFScroll5Change(TObject *Sender)
{
  char buffer[80];
  sprintf(buffer, "%d", 50-DFScroll5->Position);
	Edit1->Text = buffer;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DFScroll3Change(TObject *Sender)
{
  char buffer[80];

  sprintf(buffer, "Position is %d", DFScroll3->Position);

	Label1->Caption=buffer;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::DFScroll2Change(TObject *Sender)
{
  char buffer[80];

  sprintf(buffer, "Position is %d", DFScroll2->Position);

	Label1->Caption=buffer;

}
//---------------------------------------------------------------------------