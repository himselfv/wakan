//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "DGPSample.h"
//---------------------------------------------------------------------------
#pragma link "ClrPanel"
#pragma link "DFCtrls"
#pragma link "DFClasses"
#pragma link "ArtLabel"
#pragma link "ColorBtns"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Color95Button4Click(TObject *Sender)
{
	ArtLabel2->Caption = "Art label can contain images.";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Color95Button5Click(TObject *Sender)
{
	ArtLabel2->Caption = "Color buttons have different styles.";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Color95Button6Click(TObject *Sender)
{
	ArtLabel2->Caption = "TApples gives you a graphical sence.";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Color95Button7Click(TObject *Sender)
{
	ArtLabel2->Caption = "Color panels make you a colourful enviroment.";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Color95Button8Click(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------