//---------------------------------------------------------------------------
#ifndef ActvListSampH
#define ActvListSampH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include "ClrPanel.hpp"
#include <vcl\ExtCtrls.hpp>
#include "Backgnd.hpp"
#include "DFClasses.hpp"
#include "ColorBtns.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TColorPanel *ColorPanel1;
	TBackground *Background1;
	TColor95Button *Color95Button1;
	TColor95Button *Color95Button2;
	TColor95Button *Color95Button3;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	void __fastcall Color95Button1Click(TObject *Sender);
	void __fastcall Color95Button2Click(TObject *Sender);
	void __fastcall Color95Button3Click(TObject *Sender);
	
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
