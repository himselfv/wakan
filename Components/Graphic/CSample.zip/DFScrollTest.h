//---------------------------------------------------------------------------
#ifndef DFScrollTestH
#define DFScrollTestH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include "DFCtrls.hpp"
#include "DFClasses.hpp"
#include <vcl\ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TDFScroll *DFScroll1;
	TLabel *Label1;
	TLabel *Label3;
	TDFScroll *DFScroll2;
	TLabel *Label4;
	TDFScroll *DFScroll3;
	TLabel *Label5;
	TDFScroll *DFScroll4;
	TLabel *Label6;
	TTimer *Timer1;
	TDFScroll *DFScroll5;
	TLabel *Label2;
	TEdit *Edit1;
	TLabel *Label7;
	TShape *Shape1;
	void __fastcall DFScroll1Change(TObject *Sender);
	void __fastcall Timer1Timer(TObject *Sender);
	void __fastcall DFScroll5Change(TObject *Sender);
	void __fastcall DFScroll3Change(TObject *Sender);
	void __fastcall DFScroll2Change(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
