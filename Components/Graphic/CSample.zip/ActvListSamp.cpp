//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "ActvListSamp.h"
//---------------------------------------------------------------------------
#pragma link "ClrPanel"
#pragma link "Backgnd"
#pragma link "DFClasses"
#pragma link "ColorBtns"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Color95Button1Click(TObject *Sender)
{
	Label6->Caption = "Good moring C++ Builder!";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Color95Button2Click(TObject *Sender)
{
	Label6->Caption = "You have a meeting at two";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Color95Button3Click(TObject *Sender)
{
	Label6->Caption = "Sorry Chart is not avialable in this version";
}
//---------------------------------------------------------------------------
